
export const appName:string = 'BCards'
export const lecturer:string = 'Elran Amrussi'
export const classYear:number = 2024

// ---------------------------------------------------------------------------------------------------------

export const apiBase:string = 'https://monkfish-app-z9uza.ondigitalocean.app/bcard2'
