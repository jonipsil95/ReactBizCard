import './Footer.css';
import { Link } from 'react-router-dom';
import { FaInfoCircle, FaHeart, FaIdCard } from 'react-icons/fa'; // Importing Font Awesome icons

export default function Footer() {
  return (
    <div className='Footer'>
      <footer className='border-top pt-4'>
        <div className="container-fluid">
          <div className="row">
            <div className="col-xl-12 text-center">
              <div>
                <a href="#" className="navbar-brand">
                 
                  <span className='pt-5' style={{ fontWeight: '500', fontFamily: 'monospace', fontSize: '1rem' }}><img src="public\img\bizCard.png" className="footerLogo" /> </span>
                </a>
              </div>
              <div className="social-icons">
                <Link to="/about" className="text-decoration-none mx-3">
                  <FaInfoCircle size={20} className="mr-1" />
                  About
                </Link>
                <Link to="/favorites" className="text-decoration-none mx-3">
                  <FaHeart size={20} className="mr-1" />
                  Favorites
                </Link>
                <Link to="/mycards" className="text-decoration-none mx-3">
                  <FaIdCard size={20} className="mr-1" />
                  My Cards
                </Link>
              </div>
              <p className="mt-4">
                &copy; BizCard, {new Date().getFullYear().toString()} All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
