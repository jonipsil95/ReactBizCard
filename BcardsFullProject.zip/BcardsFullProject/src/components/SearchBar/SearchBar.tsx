import { FaMagnifyingGlass } from "react-icons/fa6";
import { useState, ChangeEvent } from 'react'; // Import ChangeEvent type

const SearchBar = () => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => { // Specify the type of 'e'
    setSearchQuery(e.target.value);
  };

  const handleSearch = () => {
    // Perform search action using the searchQuery state
    console.log('Searching for:', searchQuery);
    // You can replace the console.log with actual search functionality
  };

  return (
    <div className="col-lg-5 mx-auto w-50">
      <div className="input-group">
        <input
          className="form-control border-end-0 border rounded-3"
          type="search"
          id="header-search-input"
          value={searchQuery}
          onChange={handleInputChange}
        />
        <span className="input-group-append">
          <button
            style={{ marginLeft: '-41px' }}
            className="btn btn-outline-secondary bg-white border-bottom-0 border rounded-3"
            type="button"
            onClick={handleSearch}
          >
            <FaMagnifyingGlass />
          </button>
        </span>
      </div>
    </div>
  );
};

export default SearchBar;
