import './App.css'
import Default from './layouts/Default/Default'

export default function App() {
  return (
    <div className='App'>
      <Default/>
    </div>
  )
}
