import { createContext, useEffect, useState } from "react";
import { IUserDetails, IUserSignup } from "../interfaces/UserInterfaces";
import { doSignIn, doSignUp, fetchUserDetails, removeToken } from "../services/UserService";
import { ICard } from "../interfaces/CardInterfaces";

interface AuthContextType {
  userDetails: IUserDetails | undefined;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (userData: IUserSignup) => Promise<{ error: string | undefined }>;
  signOut: () => Promise<void>;
  likedCards: ICard[];
  addLikedCard: (card: ICard) => void;
  removeLikedCard: (cardId: string) => void;
  isAdmin: boolean; // Add isAdmin property
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export default function AuthProvider({ children }: { children: React.ReactNode }) {
  const [userDetails, setUserDetails] = useState<IUserDetails | undefined>(undefined);
  const [likedCards, setLikedCards] = useState<ICard[]>([]);
  const [isAdmin, setIsAdmin] = useState<boolean>(false); // Initialize isAdmin state

  useEffect(() => {
    const loadUserDetails = async () => {
      const { error, result } = await fetchUserDetails();
      if (error) {
        setUserDetails(undefined);
        setIsAdmin(false); // Reset isAdmin if user details loading fails
      } else {
        setUserDetails(result);
        setIsAdmin(result?.isAdmin || false); // Set isAdmin based on user details
      }
    };
    loadUserDetails();
  }, []);

  const signIn = async (email: string, password: string): Promise<{ error: string | null }> => {
    const { error, result } = await doSignIn(email, password);

    if (error) {
      signOut();
      return { error };
    }

    if (result) {
      setUserDetails(result);
      setIsAdmin(result.isAdmin || false); // Set isAdmin based on user details
      return { error: null };
    }

    return { error: null };
  };

  const signUp = async (userData: IUserSignup): Promise<{ error: string | undefined }> => {
    const { error } = await doSignUp(userData);

    if (error) {
      signOut();
      return { error };
    }

    return { error: undefined };
  };

  const signOut = async () => {
    await removeToken();
    setUserDetails(undefined);
    setLikedCards([]); // Clear liked cards when signing out
    setIsAdmin(false); // Reset isAdmin when signing out
  };

  const addLikedCard = (card: ICard) => {
    // Retrieve liked cards from local storage
    const storedLikedCards = JSON.parse(localStorage.getItem('likedCards') || '[]');

    // Check if the card already exists in liked cards
    const existingCardIndex = storedLikedCards.findIndex((c: ICard) => c._id === card._id);

    // If the card doesn't exist in liked cards, add it
    if (existingCardIndex === -1) {
      const updatedLikedCards = [...storedLikedCards, card];
      localStorage.setItem('likedCards', JSON.stringify(updatedLikedCards));
      setLikedCards(updatedLikedCards); // Update state with the updated liked cards
    }
  };

  const removeLikedCard = (cardId: string) => {
    setLikedCards(prevLikedCards => prevLikedCards.filter(card => card._id !== cardId));
  };

  return (
    <AuthContext.Provider value={{ userDetails, signIn, signOut, signUp, likedCards, addLikedCard, removeLikedCard, isAdmin }}>
      {children}
    </AuthContext.Provider>
  );
}
