
import './About.css';

const About = () => {
  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">About BizCard</h2>
      <p>
        BizCard is a platform designed to help small business owners connect with their clients more effectively.
        Our goal is to provide a simple and intuitive way for businesses to create and share their digital business
        cards, allowing them to showcase their products and services, and reach a wider audience. With BizCard, 
        businesses can easily create, customize, and share their cards, helping them stand out in today's competitive market.
      </p>
      <p>
        Our team is dedicated to providing the best possible experience for our users, and we are constantly working
        on improving our platform to meet the evolving needs of small businesses. Thank you for choosing BizCard!
      </p>
    </div>
  );
};

export default About;