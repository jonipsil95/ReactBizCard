import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';

const CardCreationForm = () => {
  const [formData, setFormData] = useState({
    title: '',
    subTitle: '',
    description: '',
    imgUrl: '', // Add img url parameter
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Handle form submission, e.g., send data to backend

    // Reset form data
    setFormData({
      title: '',
      subTitle: '',
      description: '',
      imgUrl: '', // Reset img url parameter
    });

    // Display alert
    alert('Card Added Successfully!');
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group className="mb-3" controlId="title">
        <Form.Label>Title</Form.Label>
        <Form.Control 
          type="text" 
          placeholder="Enter title" 
          name="title"
          value={formData.title}
          onChange={handleChange} 
        />
      </Form.Group>

      <Form.Group className="mb-3" controlId="subTitle">
        <Form.Label>Subtitle</Form.Label>
        <Form.Control 
          type="text" 
          placeholder="Enter subtitle" 
          name="subTitle"
          value={formData.subTitle}
          onChange={handleChange} 
        />
      </Form.Group>

      <Form.Group className="mb-3" controlId="description">
        <Form.Label>Description</Form.Label>
        <Form.Control 
          as="textarea" 
          rows={3} 
          placeholder="Enter description" 
          name="description"
          value={formData.description}
          onChange={handleChange} 
        />
      </Form.Group>

      <Form.Group className="mb-3" controlId="imgUrl">
        <Form.Label>Image URL</Form.Label>
        <Form.Control 
          type="text" 
          placeholder="Enter image URL" 
          name="imgUrl"
          value={formData.imgUrl}
          onChange={handleChange} 
        />
      </Form.Group>

      <Button variant="primary" type="submit">
        Create Card
      </Button>
    </Form>
  );
};

export default CardCreationForm;
