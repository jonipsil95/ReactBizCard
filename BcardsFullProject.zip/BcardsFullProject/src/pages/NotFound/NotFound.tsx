import './NotFound.css'

export default function NotFound() {
  return (
    <div className='NotFound Page'>
      <h1>Oh Oh</h1>
      <p>Nothing to see here yet.</p>
    </div>
  )
}
