import React, { useContext, useEffect, useState } from 'react';
import { Col, Row } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import { useNavigate } from 'react-router-dom';
import { HeartFill } from 'react-bootstrap-icons';
import { AuthContext } from '../../context/AuthContext';
import { ICard } from '../Home/Home';

const Free: React.FC = () => {
  const [cards, setCards] = useState<ICard[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [addedToFavorites, setAddedToFavorites] = useState<string[]>([]);
  const navigate = useNavigate();
  const authContext = useContext(AuthContext);

  useEffect(() => {
    const fetchCards = async () => {
      try {
        const response = await fetch('https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards', {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data);
        setCards(data);
      } catch (err) {
        const errMessage = (err as Error).message;
        setError(errMessage);
      }
    };
    fetchCards();
  }, []);

  const toggleFavorite = (cardId: string) => {
    const updatedFavorites = addedToFavorites.includes(cardId)
      ? addedToFavorites.filter((id: string) => id !== cardId)
      : [...addedToFavorites, cardId];
    setAddedToFavorites(updatedFavorites);

    // Store the updated favorites in the local storage
    localStorage.setItem('favorites', JSON.stringify(updatedFavorites));
  };

  const goToCardDetails = (cardId: string) => {
    navigate(`/card-details/${cardId}`, { state: { cardId } });
  };

  const deleteCard = (cardId: string) => {
    // Remove the deleted card from the cards array in the state
    setCards(prevCards => prevCards.filter(card => card._id !== cardId));
  };

  return (
    <div className='Free Page'>
      <h3>All Cards </h3>
      <br />
      {error && <p>Error getting cards :-\ <br />{error}</p>}
      <Row xs={1} md={2} lg={3} xl={4} className='g-5'>
        {cards.map(card => (
          <Col key={card._id}>
            <Card className='text-center'>
              <Card.Header style={{ fontWeight: '500' }}>{card.title}</Card.Header>
              <Card.Body>
                <Card.Img variant='top' src={card.image.url} style={{ height: '200px', width: '200px', objectFit: 'cover' }} />
                <Card.Title>{card.subTitle}</Card.Title>
                <Button variant='primary' size='sm' onClick={() => goToCardDetails(card._id)}>
                  Go to card
                </Button>
                <Button
                  variant='outline-danger'
                  size='sm'
                  className='ms-2'
                  onClick={() => deleteCard(card._id)}
                  disabled={!authContext?.isAdmin} // Disable delete button if not admin
                >
                  Remove From list
                </Button>
                <Button
                  variant='outline-danger'
                  size='sm'
                  className='ms-2'
                  onClick={() => toggleFavorite(card._id)}
                >
                  {addedToFavorites.includes(card._id) ? (
                    <HeartFill color="red" />
                  ) : (
                    'Add to Favorites'
                  )}
                </Button>
              </Card.Body>
              <Card.Footer className='text-muted'></Card.Footer>
            </Card>
          </Col>
        ))}
      </Row>
      <h5>Total {cards.length} card</h5>
    </div>
  );
};

export default Free;
