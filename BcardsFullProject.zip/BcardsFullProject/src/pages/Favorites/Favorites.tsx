import React, { useEffect, useState } from 'react';
import { Col, Row } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import { ICard } from '../Home/Home';

const Favorites: React.FC = () => {
  const [favoriteCards, setFavoriteCards] = useState<ICard[]>([]);

  useEffect(() => {
    const fetchFavoriteCards = async () => {
      try {
        // Retrieve favorite card IDs from local storage
        const favoritesFromStorage = localStorage.getItem('favorites');
        if (favoritesFromStorage) {
          const favoriteIds: string[] = JSON.parse(favoritesFromStorage);

          // Fetch favorite cards from the API using their IDs
          const fetchedFavoriteCards = await Promise.all(favoriteIds.map(async (id: string) => {
            const response = await fetch(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/${id}`, {
              method: 'GET',
              headers: { 'Content-Type': 'application/json' },
            });
            const data = await response.json();
            return data;
          }));

          setFavoriteCards(fetchedFavoriteCards);
        }
      } catch (err) {
        console.error('Error fetching favorite cards:', err);
      }
    };

    fetchFavoriteCards();
  }, []);

  const removeFromFavorites = (cardId: string) => {
    // Remove the card ID from favorites array
    const updatedFavorites = favoriteCards.filter(card => card._id !== cardId);
    setFavoriteCards(updatedFavorites);

    // Store the updated favorites in the local storage
    const updatedFavoriteIds = updatedFavorites.map(card => card._id);
    localStorage.setItem('favorites', JSON.stringify(updatedFavoriteIds));
  };

  return (
    <div className="Favorites Page">
      <h3>Favorite Cards</h3>
      <Row xs={1} md={2} lg={3} xl={4} className="g-5">
        {favoriteCards.map((card: ICard) => (
          <Col key={card._id}>
            <Card className="text-center">
              <Card.Header style={{ fontWeight: '500' }}>{card.title}</Card.Header>
              <Card.Body>
                <Card.Img variant="top" src={card.image.url} style={{ height: '200px', width: '200px', objectFit: 'cover' }} />
                <Card.Title>{card.subTitle}</Card.Title>
                <Button variant="primary" size="sm">
                  Go to Card
                </Button>
                <Button
                  variant="outline-danger"
                  size="sm"
                  className="ms-2"
                  onClick={() => removeFromFavorites(card._id)}
                >
                  Remove from Favorites
                </Button>
              </Card.Body>
              <Card.Footer className="text-muted">Actions here...</Card.Footer>
            </Card>
          </Col>
        ))}
      </Row>
      <br />
      <br />
      <h5>Total {favoriteCards.length} favorite cards</h5>
    </div>
  );
};

export default Favorites;
