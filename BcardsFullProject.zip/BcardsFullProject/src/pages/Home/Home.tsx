import React, { useEffect, useState } from 'react';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import { useNavigate } from 'react-router-dom';

export interface ICard {
  _id: string;
  title: string;
  subTitle: string;
  description: string;
  image: { url: string; alt: string };
  bizNumber: number;
  user_id: string;
  isFavorite: boolean;
}

const Home: React.FC = () => {
  const [randomCard, setRandomCard] = useState<ICard | null>(null);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRandomCard = async () => {
      try {
        const response = await fetch('https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards', {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data);
        const randomIndex = Math.floor(Math.random() * data.length);
        setRandomCard(data[randomIndex]);
      } catch (err) {
        const errMessage = (err as Error).message;
        setError(errMessage);
      }
    };
    fetchRandomCard();
  }, []);

  const goToCardDetails = (cardId: string) => {
    navigate(`/card-details/${cardId}`, { state: { cardId } });
  };

  return (
    <div className='Home Page'>
    
     
      
      <br />
      
    <img src="public\img\bizCard.png" alt="" />
    <h1>Welcome To BizCard App!</h1>
      <h3>Discover new business cards every time you visit.</h3>
      <p>Here's some random card for you:</p>
      {error && <p>Error getting random card :-\ <br />{error}</p>}
      {randomCard && (
        <Card className='text-center'>
          <Card.Header style={{ fontWeight: '500' }}>{randomCard.title}</Card.Header>
      <Card.Body className="custom-card-body">
  <Card.Img variant='top' src={randomCard.image.url} style={{ height: '200px', width: '200px', objectFit: 'cover' }} />
  <Card.Title>{randomCard.subTitle}</Card.Title>
  <Button variant='primary' size='sm' onClick={() => goToCardDetails(randomCard._id)}>Go to card</Button>
</Card.Body>

          <Card.Footer className='text-muted'></Card.Footer>
        </Card>
      )}
    </div>
  );
};

export default Home;
